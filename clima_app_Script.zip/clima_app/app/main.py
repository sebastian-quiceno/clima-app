from flask import Flask, render_template, request
import requests

app = Flask(__name__)
API_KEY = "717f7254be8a95bdcb1214a70e721933"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/clima', methods=['POST'])
def clima():
    ciudad = request.form['ciudad']
    url = f'https://api.openweathermap.org/data/2.5/weather?q={ciudad}&appid={API_KEY}&units=metric&lang=es'

    respuesta = requests.get(url)
    if respuesta.status_code == 200:
        datos = respuesta.json()
        temperatura = datos['main']['temp']
        descripcion = datos['weather'][0]['description']
        return render_template('resultado.html', ciudad=ciudad, temperatura=temperatura, descripcion=descripcion)
    else:
        return render_template('resultado.html', error='No se pudo obtener el clima de esa ciudad.')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
