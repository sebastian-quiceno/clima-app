#!/bin/bash

# Construir la imagen Docker con el nombre clima-app
docker build -t clima-app .

# Ejecutar el contenedor y mapear el puerto 5000
docker run -p 5000:5000 clima-app
